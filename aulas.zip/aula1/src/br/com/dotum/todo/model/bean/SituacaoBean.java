package br.com.dotum.todo.model.bean;

public class SituacaoBean {

	private Integer id;
	private String descricao;
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return this.id;
	}
	
	
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public String getDescricao() {
		return this.descricao;
	}
	
	
	
}
