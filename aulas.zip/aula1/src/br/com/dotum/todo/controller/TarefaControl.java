package br.com.dotum.todo.controller;

import java.util.List;
import java.util.Scanner;

import br.com.dotum.todo.dao.TarefaDao;
import br.com.dotum.todo.model.bean.TarefaBean;
import br.com.dotum.todo.view.TarefaView;

public class TarefaControl {

	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);


		Integer opcao = null;
		do {
			TarefaView tView = new TarefaView();
			tView.criarTelaMenu();
			opcao = s.nextInt();

			if (opcao.equals(1)) {

				tView.criarTelaAdicionarTarefa();
				String descricaoTarefa = s.next();
				String cor = s.next();

				TarefaDao dao = new TarefaDao();
				dao.adicionarTarefa(descricaoTarefa, cor);

				tView.criarMensagemSucesso();

			} else if (opcao.equals(2)) {
				
				TarefaDao dao = new TarefaDao();
				List<TarefaBean> tarList = dao.getTarefaList();

				tView.criarTelaListarTarefa(tarList);
			}

		} while (opcao.equals(5) == false);

		s.close();
	}

}
