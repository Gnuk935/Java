package br.com.dotum.todo.view;

import java.util.List;

import br.com.dotum.todo.model.bean.TarefaBean;

public class TarefaView {

	public void criarTelaMenu() {
		
		
		int i = 0;
		System.out.println((++i) + " - Adicionar tarefa");
		System.out.println((++i) + " - Listar tarefa");
		System.out.println((++i) + " - Adicionar tarefa com percentual");
		System.out.println((++i) + " - Definir percentual");
		System.out.println((++i) + " - Cancelar tarefa");
		System.out.println((++i) + " - Sair");
		System.out.println("<div>Digite o numero referente a uma das "+ i +" opções: </div>");

	}

	public void criarTelaAdicionarTarefa() {
		System.out.println("Digite a descrição da tarefa: ");
	}

	public void criarTelaListarTarefa(List<TarefaBean> tarList) {

		for (int i = 0; i < tarList.size(); i++) {
			TarefaBean tarBean = tarList.get(i);
			System.out.println("" + tarBean.getId()  + " - " + tarBean.getDescricao() + " - " + tarBean.getPercentual());
		}
		System.out.println("=============================");
	}

	public void criarTelaDefinirPercentual() {

	}

	public void criarTelaCancelarTarefa() {

	}

	public void criarMensagemSucesso() {
		System.out.println("Tarefa adicionada com sucesso");
		System.out.println("=============================");
	}

}
