package br.com.dotum.todo.dao;

import java.util.ArrayList;
import java.util.List;

import br.com.dotum.todo.model.bean.SituacaoBean;
import br.com.dotum.todo.model.bean.TarefaBean;

public class TarefaDao {
	
	private static Integer tarefaId = 0;
	
	// falar e explicar o static la na frente!!!
	private static List<TarefaBean> tarList = new ArrayList<TarefaBean>();
	
	public void adicionarTarefa(String descricao, String cor) {
		
		TarefaBean tarBean = new TarefaBean();
		tarBean.setId(++tarefaId);
		tarBean.setPercentual(0);
		tarBean.setDescricao(descricao);
		tarBean.setCor(cor);
		

		SituacaoDao sitDao = new SituacaoDao();
		SituacaoBean sitBean = sitDao.getPendente();
		
		tarBean.setSituacao(sitBean);
		tarList.add(tarBean);
	}
	
	public List<TarefaBean> getTarefaList() {
		return tarList;
	}
	
}
