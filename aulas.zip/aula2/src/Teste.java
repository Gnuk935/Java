
public class Teste {

	public static void main(String[] args) {
		
		int x = 0;
		for (int i = 0; i < 3; i++) {
			
			
			System.out.println( x-- );
			
		}
		
	}
	
}
