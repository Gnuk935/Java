package br.com.dotum.todo.view;

import java.util.List;

import br.com.dotum.todo.control.TarefaControl;
import br.com.dotum.todo.model.bean.TarefaBean;

public class TarefaView {

	public void criaTelaBemVindo() {
		System.out.println("Bem vindo ao TODO.");
		System.out.println("Serve para facilitar a listagem das suas tarefas.");
		System.out.println("");
		System.out.println("Olhe abaixo e vejas as opções para interagir com o TODO");
	}
	
	public void criaTelaPrincipal() {
		System.out.println("=======================");
		System.out.println(TarefaControl.INSERIR + " - Inserir Tarefa");
		System.out.println(TarefaControl.EVOLUIR + " - Evoluir % da Tarefa");
		System.out.println(TarefaControl.CANCELAR + " - Cancelar Tarefa");
		System.out.println(TarefaControl.LISTAR + " - Listar tarefas");
		System.out.println(TarefaControl.SAIR + " - Sair");
		System.out.println("=======================");
		
	}
	public void criaTelaInserirTarefa() {
		System.out.println("Insira a descricao da tarefa: ");
	}

	public void criaTelaTarefaInseridaComSucesso() {
		System.out.println("Tarefa inserida com sucesso!");
	}

	public void criaTelaSaiuDoPrograma() {
		System.out.println("Programa Desligado");
	}

	public void criaMessagemErroColocaUmNumero() {
		System.out.println("Coloca um numero!!!");		
	}
	
	public void criaTelaListagemtarefa(List<TarefaBean> tarList) {
		for (int i = 0; i < tarList.size(); i++) {
			TarefaBean tarBean = tarList.get(i);
			
			Integer id = tarBean.getId();
			String descricao = tarBean.getDescricao();
			Integer percentual = tarBean.getPercentual();
			
			System.out.println(id + ". " + descricao + " - " + percentual);
		}
	}
}
