package br.com.dotum.todo.control;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import br.com.dotum.todo.model.bean.TarefaBean;
import br.com.dotum.todo.model.dao.TarefaDao;
import br.com.dotum.todo.view.TarefaView;

public class TarefaControl {

	public static final Integer INSERIR = 1;
	public static final Integer EVOLUIR = 2;
	public static final Integer CANCELAR = 3;
	public static final Integer LISTAR = 4;
	public static final Integer SAIR = 5;
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);


		Integer opcao = null;
		TarefaView tView = new TarefaView();
		tView.criaTelaBemVindo();

		do {
			tView.criaTelaPrincipal();
			try {
				opcao = s.nextInt();
			} catch (InputMismatchException e) {
				tView.criaMessagemErroColocaUmNumero();
			}

			if (opcao.equals(INSERIR)) {

				tView.criaTelaInserirTarefa();
				String descricao = s.next();


				TarefaDao tDao = new TarefaDao();
				tDao.inserirTarefa(descricao);

				tView.criaTelaTarefaInseridaComSucesso();

			} else if (opcao.equals(2)) {
			} else if (opcao.equals(3)) {
			} else if (opcao.equals(LISTAR)) {
				
				TarefaDao tDao = new TarefaDao();
				List<TarefaBean> tarList = tDao.getTarefaList();
				tView.criaTelaListagemtarefa(tarList);
				

			} 

		} while (opcao.equals(5) == false);
		
		tView.criaTelaSaiuDoPrograma();
		s.close();
		
	}


}
