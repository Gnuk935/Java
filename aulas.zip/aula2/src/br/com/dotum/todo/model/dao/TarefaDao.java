package br.com.dotum.todo.model.dao;

import java.util.ArrayList;
import java.util.List;

import br.com.dotum.todo.model.bean.SituacaoBean;
import br.com.dotum.todo.model.bean.TarefaBean;

public class TarefaDao {
	
	private static final int id = 0;
	private static List<TarefaBean> tarList = new ArrayList<TarefaBean>();

	public void inserirTarefa(String descricao) {
		
		SituacaoDao sDao = new SituacaoDao();
		SituacaoBean sitBean = sDao.getPendente();

		
		TarefaBean tarBean = new TarefaBean();
		tarBean.setId(++id);
		tarBean.setDescricao(descricao);
		tarBean.setSituacao(sitBean);
		tarBean.setPercentual(0);

		
		tarList.add(tarBean);
	}
	
	public List<TarefaBean> getTarefaList() {
		return tarList;
	}
}
