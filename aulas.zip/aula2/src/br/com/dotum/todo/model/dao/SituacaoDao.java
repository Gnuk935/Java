package br.com.dotum.todo.model.dao;

import br.com.dotum.todo.model.bean.SituacaoBean;

public class SituacaoDao {

	public SituacaoBean getPendente() {
		SituacaoBean sitBean = new SituacaoBean();
		sitBean.setDescricao("Pendente");

		return sitBean;
	}
	public SituacaoBean getAndamento() {
		SituacaoBean sitBean = new SituacaoBean();
		sitBean.setDescricao("Andamento");
		
		return sitBean;
	}
	public SituacaoBean getConcluido() {
		SituacaoBean sitBean = new SituacaoBean();
		sitBean.setDescricao("Concluido");
		
		return sitBean;
	}
	
	public SituacaoBean getCancelado() {
		SituacaoBean sitBean = new SituacaoBean();
		sitBean.setDescricao("Cancelado");
		
		return sitBean;
	}
	
}
