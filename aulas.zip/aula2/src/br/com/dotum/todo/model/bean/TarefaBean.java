package br.com.dotum.todo.model.bean;

public class TarefaBean {

	private Integer id;
	private String descricao;
	private Integer percentual;
	private SituacaoBean situacao;
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return this.id;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Integer getPercentual() {
		return percentual;
	}

	public void setPercentual(Integer percentual) {
		this.percentual = percentual;
	}

	public SituacaoBean getSituacao() {
		return situacao;
	}

	public void setSituacao(SituacaoBean situacao) {
		this.situacao = situacao;
	}
	
	
	
}
